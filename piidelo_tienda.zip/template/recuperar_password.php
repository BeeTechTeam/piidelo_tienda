<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Quicksand:wght@300&display=swap");
        body {
            font-family: "Quicksand";
        }
    </style>
</head>

<body>
    <div style="text-align: center;">
        <h1>Recuperaci&oacute;n de contraseña de <a href="https://www.piidelo.com">piidelo.com</a> </h1>
        <img src="../image/logo.png" alt="Piidelo.com" title="Piidelo.com" width="500px">
        <p>Tu contraseña es: <b>password</b></p>
        <p>Te recomendamos cambiarla, anotarla y guardarla en un lugar seguro.</p>
        <p>Atentamente: Equipo de soporte de Piidelo.com</p>
    </div>
</body>

</html>